# Data 200: Data Systems for Data Analytics


# Name:

# Take Home Final Exam
<font color='red'>**Due Date:** Dec 20, 5p (T-F 1:30p section) </font> <br>
<font color='red' style="margin-left: 1.85cm; display: inline-block;">Dec 21, 11:59a (T-F 3p section)</font>

---

### **Task**: Scrape data from Goodreads.com 📚

---

### **Objective**
For this exam, you will scrape and analyze data from Goodreads.com. The work is split into two parts, each focusing on different aspects of the data
1. **"Best Books" Analysis**: Explore Goodreads' "Best Books" lists for a specific year.
2. **Author-Level Analysis**: Study the trends and patterns in the works of a specific author.

---

### **Instructions**

#### **Task 1: Best Books**
You are tasked with analyzing Goodreads' "Best Books" lists for a specific year based on the **first letter of your first name**. For example, if your first name starts with **A–E**, you are assigned to the year **2023**; if it starts with **F–J**, you are assigned to **2022**, and so on:

| Initials | Assigned Year | URL                                              |
|----------|---------------|---------------------------------------------------------|
| A–E      | 2023          | [Best Books of 2023](https://www.goodreads.com/list/best_of_year/2023) |
| F–J      | 2022          | [Best Books of 2022](https://www.goodreads.com/list/best_of_year/2022) |
| K–O      | 2021          | [Best Books of 2021](https://www.goodreads.com/list/best_of_year/2021) |
| P–T      | 2020          | [Best Books of 2020](https://www.goodreads.com/list/best_of_year/2020) |
| U–Z      | 2019          | [Best Books of 2019](https://www.goodreads.com/list/best_of_year/2019) |



**Your Tasks**:
1. Scrape data from the Goodreads "Best Books of [Year]" list:
   - **URL**: https://www.goodreads.com/list/best_of_year/2023 (replace the year with your assigned year). You can also use the table above.
2. Collect the following data for each book:
   - Title
   - Publication date (first published)
   - Author
   - Genre (if available, and feel free to pick the first genre listed)
   - Average rating
   - Number of ratings
   - Number of pages
   - Rank
   - Language (if available)
   - Number of people who are currently reading (if available)
   - Number of people who want to read (if available)
3. Perform the following analyses:
   - **Genre ratings**:
       - Compare average ratings across genres. Which 2-3 genres tends to have the highest ratings? Create a table showing average rating score, and average rank by genre.
   - **Popularity and ratings**:
       - Examine whether books with more ratings tend to have higher or lower average scores. Create a scatterplot showing the relationship between the number of ratings and average rating. On the x-axis, you should have **number of ratings**; on the y-axis, you should have **average rating**.

---

#### **Task 2: Author-Level Analysis**
You are now tasked with analyzing books by a specific author based on the **first letter of your first name**:

| Your first name initial | Author              | Author Goodreads link                               | Birthday       |
|----------|---------------------|--------------------------------------------------------------------|----------------|
| A–E      | Stephen King        | [Stephen King](https://www.goodreads.com/author/list/3389)         | Sep 21, 1947   |
| F–J      | George R.R. Martin  | [George R.R. Martin](https://www.goodreads.com/author/list/346732) | Sep 20, 1948   |
| K–O      | Ernest Hemingway    | [Ernest Hemingway](https://www.goodreads.com/author/list/1455)     | Jul 21, 1899   |
| P–T      | Neil Gaiman         | [Neil Gaiman](https://www.goodreads.com/author/list/1221698)       | Nov 10, 1960   |
| U–Z      | Nora Roberts        | [Nora Roberts](https://www.goodreads.com/author/list/625)          | Oct 10, 1950   |


**Your Tasks**:
1. Scrape all books by your assigned author:
   - Use the link provided for your author.
2. Collect the following data for each book:
   - Title
   - Publication date (first published)
   - Author
   - Genre (if available, and feel free to pick the first genre listed)
   - Average rating
   - Number of ratings
   - Number of pages
   - Rank (from the books written by the author)
   - Language (if available)
   - Number of people who are currently reading (if available)
   - Number of people who want to read (if available)
3. Perform the following analyses:
   - **Language Distribution**:
     - How many books has the author published in English? In other languages? Create a table showing the count of books by language.
   - **Author's Age and Page Count**:
     - Do authors tend to write longer books as they age? Use the author's birthday to calculate their age at the time of each book's publication. Create a line plot with **author's age** on the x-axis and **page count** on the y-axis.
   - **Author's Age and Rating**:
     - For English-only books, create a line plot with **author's age** on the x-axis and **average rating** on the y-axis.
     - Repeat the analysis including books in languages other than English. Does your interpretation change?
   - **Pages vs. Ratings**:
     - Is there a relationship between the number of pages and a book's average rating? Create a scatterplot with **page count** on the x-axis and **average rating** on the y-axis.
   - **Interest on a book**:
     - Is there a relationship between the number of people who are currently reading the book and the number of people who left a rating? Create a scatterplot with **number of people who are currently reading** on the x-axis and **number of ratings** on the y-axis. Create a second scatterplot with **average rating** on the y-axis. Do books with more interest tend to receive higher ratings?

---

### **Submission Requirements**
Submit your work as a single `.ipynb` file, along with a copy of it as a `.md` file. The notebook should include:
1. **Code**:
   - Well-documented python code using Selenium for web scraping.
   - Proper error handling and strategies for dynamic content.
2. **Cleaned Data**:
   - Include the cleaned datasets from both tasks as .csv files. You can upload them in your github repo.
3. **Analysis and Report**:
   - Present your findings using markdown cells, tables, and visualizations you make in python.
   - Address all questions posed for your assigned tasks.
4. **Visualizations**:
   - Include relevant charts (e.g., bar charts, line plots, scatterplots) to support your conclusions.

---

### **Rubric**

| Item                        | Weight |
|-----------------------------|--------|
| Code accuracy               | 25%    |
| Code clarity and annotation | 25%    |
| Exploratory data analysis   | 25%    |
| Discussion of findings      | 25%    |

---

### **Tips**
- Make sure to insert time.sleep() right after you request driver to go to a link (before requesting elements). Make sure to wait at least 0.7 second, or even slightly higher if you run into issues.
- Try-except blocks will be your friend because xpath positions on a page may differ depending on the book and content availability.

---

### **Resources**
- Course notes on Github
- Selenium documentation: https://www.selenium.dev/documentation/
- Pandas documentation: https://pandas.pydata.org/docs/
- Matplotlib documentation: https://matplotlib.org/stable/contents.html

Good luck! 🏁


# Task 1: Best Books for the year 2020. The code below is my script for web scraping the website.



```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import time

# Initialize the WebDriver
driver = webdriver.Chrome()

# Base URL for the Goodreads list
base_url = 'https://www.goodreads.com/list/best_of_year/2020?id=143444.Best_Books_of_2020&page={}'

# Initialize a list to store book details
books_data = []

# Function to click "Book details & editions" and extract language
def get_language():
    try:
        # Click the "Book details & editions" button
        details_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="Book details and editions"]'))
        )
        driver.execute_script("arguments[0].click();", details_button)
        time.sleep(2)  # Allow time for the content to load

        # Extract the language information
        language_element = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, '//dt[text()="Language"]/following-sibling::dd'))
        )
        return language_element.text
    except Exception as e:
        print(f"Error extracting language: {e}")
        return "Not available"

# Function to scrape data from the book's detailed page
def scrape_book_details():
    try:
        # Publication Date
        try:
            publication_date = driver.find_element(By.XPATH, '//p[@data-testid="publicationInfo"]').text
        except:
            publication_date = "Not available"

        # Genre
        try:
            genre = driver.find_element(By.XPATH, '//div[contains(@class, "genres")]//a[1]').text
        except:
            genre = "Not available"

        # Number of Pages
        try:
            pages_info = driver.find_element(By.XPATH, '//p[@data-testid="pagesFormat"]').text
            num_pages = pages_info.split(" pages")[0]
        except:
            num_pages = "Not available"

        # Language by clicking "Book details & editions"
        language = get_language()

        # Extract Currently Reading and Want to Read
        try:
            currently_reading = driver.find_element(
                By.XPATH,
                '//*[@id="__next"]/div[2]/main/div[1]/div[2]/div[2]/div[2]/div[8]/div/div[1]/span/div[2]/div'
            ).text
        except Exception:
            currently_reading = "Not available"

        try:
            want_to_read = driver.find_element(
                By.XPATH,
                '//*[@id="__next"]/div[2]/main/div[1]/div[2]/div[2]/div[2]/div[8]/div/div[2]/span/div[2]/div'
            ).text
        except Exception:
            want_to_read = "Not available"

        return publication_date, genre, num_pages, language, currently_reading, want_to_read
    except Exception as e:
        print(f"Error scraping book details: {e}")
        return "Not available", "Not available", "Not available", "Not available", "Not available", "Not available"

# Function to scrape data from the current page
def scrape_current_page():
    row_count = len(driver.find_elements(By.XPATH, '//*[@id="all_votes"]/table/tbody/tr'))
    for index in range(1, row_count + 1):
        try:
            # Refresh the row dynamically using its index
            row = driver.find_element(By.XPATH, f'//*[@id="all_votes"]/table/tbody/tr[{index}]')

            # Extract Rank
            try:
                rank = row.find_element(By.XPATH, f'./td[1]').text
            except:
                rank = "Not available"

            # Extract Title
            title = row.find_element(By.XPATH, './td[3]/a/span').text

            # Extract Author
            try:
                author = row.find_element(By.XPATH, './td[3]/span[2]').text
            except:
                author = "Not available"

            # Extract Average Rating and Number of Ratings
            try:
                rating_info = row.find_element(By.XPATH, './td[3]/div/span/span').text
                rating_parts = rating_info.split(' — ')
                average_rating = rating_parts[0]
                num_ratings = rating_parts[1] if len(rating_parts) > 1 else "Not available"
            except:
                average_rating = "Not available"
                num_ratings = "Not available"

            # Click the book link to go to the detailed page
            book_link = row.find_element(By.XPATH, './td[3]/a')
            book_link.click()

            # Wait for the detailed page to load
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//p[@data-testid="publicationInfo"]'))
            )

            # Scrape details from the detailed page
            publication_date, genre, num_pages, language, currently_reading, want_to_read = scrape_book_details()

            # Navigate back to the main list page
            driver.back()

            # Wait for the main page to reload
            WebDriverWait(driver, 10).until(
                EC.presence_of_all_elements_located((By.XPATH, '//*[@id="all_votes"]/table/tbody/tr'))
            )

            # Append extracted data
            books_data.append({
                "Rank": rank,
                "Title": title,
                "Author": author,
                "Average Rating": average_rating,
                "Number of Ratings": num_ratings,
                "Publication Date": publication_date,
                "Genre": genre,
                "Number of Pages": num_pages,
                "Language": language,
                "Currently Reading": currently_reading,
                "Want to Read": want_to_read,
            })
            print(f"Book {rank}: {title} {language} {want_to_read} {currently_reading} extracted successfully")

        except Exception as e:
            print(f"Error processing book at row {index}: {e}")

# Loop through all the pages
for page_number in range(1, 18):  
    print(f"Scraping page {page_number}...")
    try:
        driver.get(base_url.format(page_number))

        # Wait for rows to load
        WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.XPATH, '//*[@id="all_votes"]/table/tbody/tr'))
        )

        # Scrape the current page
        scrape_current_page()

    except Exception as e:
        print(f"Error loading or scraping page {page_number}: {e}")
        break

# Save the data to a CSV file
df = pd.DataFrame(books_data)
df = df.apply(lambda x: x.str.strip() if x.dtype == "object" else x)  # Clean up any extra spaces
df.to_csv('goodreads_books3_2020.csv', index=False)
print("Data saved to goodreads_books3_2020.csv")

# Close the driver
driver.quit()

```

## I had issues getting the want to read the currently reading in the above script, so I made another script just retrieving those attributes. This is shown below.


```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
import pandas as pd
import time

# Initialize WebDriver options
options = Options()
options.headless = True  # Run browser in headless mode (no GUI)

# Base URL for the Goodreads Best Books of 2020 list
base_url = 'https://www.goodreads.com/list/best_of_year/2020?id=143444.Best_Books_of_2020&page={}'

# Function to get all book links from the current list page
def get_book_urls(driver):
    """
    Collect all book URLs from the current Goodreads list page.
    """
    try:
        links = driver.find_elements(By.XPATH, "//a[@class='bookTitle']")
        return [link.get_attribute('href') for link in links]
    except Exception as e:
        print(f"Error collecting book URLs: {e}")
        return []

# Function to scrape book title, 'Currently Reading', and 'Want to Read'
def scrape_book_data(book_url):
    """
    Visit a book page and extract 'Title', 'Currently Reading', and 'Want to Read'.
    """
    driver = webdriver.Chrome(options=options)
    driver.get(book_url)
    time.sleep(1)  # Allow the page to load fully

    try:
        # Extract Book Title
        try:
            title = driver.find_element(By.XPATH, "//h1[@data-testid='bookTitle']").text.strip()
        except:
            title = "Title not available"

        # Extract "Currently Reading"
        try:
            currently_reading = driver.find_element(
                By.XPATH, "//*[@data-testid='currentlyReadingSignal' and @class='SocialSignalsSection__caption']"
            ).text.split()[0]
        except:
            currently_reading = "Not available"

        # Extract "Want to Read"
        try:
            want_to_read = driver.find_element(
                By.XPATH, "//*[@data-testid='toReadSignal' and @class='SocialSignalsSection__caption']"
            ).text.split()[0]
        except:
            want_to_read = "Not available"

        print(f"Scraped: {title} | Currently Reading: {currently_reading} | Want to Read: {want_to_read}")
        return [book_url, title, currently_reading, want_to_read]

    except Exception as e:
        print(f"Error scraping {book_url}: {e}")
        return [book_url, "Title not available", "Not available", "Not available"]
    finally:
        driver.quit()

# Initialize DataFrame to store results
df = pd.DataFrame(columns=['URL', 'Title', 'Currently Reading', 'Want to Read'])

# Main loop to iterate through pages of the list
for page in range(1, 18):  
    print(f"Collecting book URLs from page {page}...")
    driver = webdriver.Chrome(options=options)
    driver.get(base_url.format(page))
    time.sleep(2)  # Allow time for the page to load

    # Get all book URLs on the current page
    book_urls = get_book_urls(driver)
    driver.quit()

    # Visit each book URL and extract data
    page_data = []
    for url in book_urls:
        book_data = scrape_book_data(url)
        page_data.append(book_data)

    # Append the page data to the DataFrame
    df_page = pd.DataFrame(page_data, columns=['URL', 'Title', 'Currently Reading', 'Want to Read'])
    df = pd.concat([df, df_page], ignore_index=True)

# Save the final results to a CSV file
df.to_csv('goodreads_best_books_2020.csv', index=False)
print("Data saved to goodreads_best_books_2020.csv")
```

## Merging the two files to get a file with all the attributes


```python
import pandas as pd

# Load the two datasets
books3_df = pd.read_csv("goodreads_books3_2020.csv")  # Original file
best_books_df = pd.read_csv("goodreads_best_books_2020.csv")  # File with updated columns

# Ensure data alignment by matching on the "Title" column
merged_df = books3_df.drop(columns=["Currently Reading", "Want to Read"]).merge(
    best_books_df[["Title", "Currently Reading", "Want to Read"]],
    on="Title",
    how="left"
)

# Save the updated file
merged_df.to_csv("goodreads_books3_updated_2020.csv", index=False)

print("Columns replaced successfully! Updated file saved as 'goodreads_books3_updated_2020.csv'.")
```

## Comparing Average Ratings Across Genres

### Objective:
- To identify which **2-3 genres** tend to have the **highest average ratings**.
- Create a table that displays:
  - The **average rating score** for each genre.
  - The **average rank** for each genre.

### Methodology:
1. **Data Cleaning**:
   - Use **pandas** to clean the data by ensuring valid numeric values for:
     - **Average Rating**
     - **Rank**
   - Handle any missing or invalid data.

2. **Grouping and Aggregation**:
   - Group the data by **Genre**.
   - Calculate the **average rating** and **average rank** for each genre.

3. **Output**:
   - Create a table that displays the results, ordered by **average rating** in descending order.






```python
import pandas as pd

# Read CSV file
df = pd.read_csv('goodreads_books3_updated_2020.csv')

# Clean and convert 'Average Rating' to numeric (remove text like 'avg rating')
df['Average Rating'] = pd.to_numeric(df['Average Rating'].str.extract(r'(\d+\.\d+)')[0], errors='coerce')

# Group by 'Genre' and calculate average rating and average rank
genre_summary = df.groupby('Genre').agg({
    'Average Rating': 'mean',
    'Rank': 'mean'
}).sort_values(by='Average Rating', ascending=False)

# Rename columns for clarity
genre_summary.columns = ['Average Rating', 'Average Rank']

pd.set_option('display.max_rows', None)

# Display the table
print(genre_summary)

#Display the top 3 genres with the highest ratings
print("Top 3 Genres with Highest Ratings:")
print(genre_summary.head(3))

```

                                Average Rating  Average Rank
    Genre                                                   
    Nature                            4.560000   1338.000000
    Time Travel                       4.540000    516.000000
    Fairy Tales                       4.500000    924.000000
    Childrens                         4.500000   1076.000000
    Manga                             4.487500    617.000000
    Christian                         4.440000   1160.000000
    Gothic                            4.410000    924.000000
    Health                            4.400000   1351.000000
    Writing                           4.390000    350.000000
    Urban Fantasy                     4.342222    880.444444
    Autistic Spectrum Disorder        4.320000    924.000000
    Science Fiction Fantasy           4.310000   1532.000000
    Anthologies                       4.300000    305.000000
    Finance                           4.300000    553.000000
    Suspense                          4.290000   1053.000000
    Mythology                         4.290000    345.000000
    Magical Realism                   4.290000    981.000000
    Essays                            4.280000   1430.000000
    Paranormal                        4.277500    882.750000
    Contemporary Romance              4.270000    988.000000
    Christian Fiction                 4.238000    689.600000
    Astrology                         4.220000    924.000000
    Technology                        4.210000   1526.000000
    Reverse Harem                     4.202500    394.875000
    Christmas                         4.200000    908.000000
    Middle Grade                      4.193000   1021.500000
    Picture Books                     4.190000    745.000000
    Graphic Novels                    4.184545    745.181818
    M M Romance                       4.173333    679.833333
    Post Apocalyptic                  4.170000    436.000000
    History                           4.164375    914.968750
    Science                           4.164000    694.800000
    Crime                             4.140000    831.666667
    Politics                          4.139375    886.562500
    Historical Romance                4.131429    818.000000
    Contemporary                      4.130000    835.000000
    Mermaids                          4.130000   1076.000000
    Dark                              4.123333    608.666667
    Not available                     4.118000    870.866667
    Sports Romance                    4.110000   1053.000000
    Psychology                        4.100000    422.000000
    Poetry                            4.092500    781.875000
    High School                       4.090000   1076.000000
    Comics                            4.083333   1117.333333
    Nonfiction                        4.082917    830.260417
    Music                             4.080000    698.500000
    Presidents                        4.080000   1203.000000
    Memoir                            4.075385    651.615385
    Humor                             4.028000    763.000000
    Historical Fiction                4.018136    699.288136
    Fantasy                           4.016435    682.400000
    Mystery                           4.005152    749.151515
    Romance                           3.978010    785.145631
    Cookbooks                         3.950000   1295.000000
    Sports                            3.930000   1426.000000
    Economics                         3.930000   1215.000000
    Dystopia                          3.910000    783.750000
    Short Stories                     3.901000    926.100000
    Audiobook                         3.900000    756.000000
    Thriller                          3.877407    636.259259
    Science Fiction                   3.875652    844.782609
    Young Adult                       3.874000    647.950000
    New Adult                         3.870000    946.000000
    Biography                         3.865000    858.000000
    Fashion                           3.830000   1409.000000
    Feminism                          3.820000   1076.000000
    LGBT                              3.805000    271.500000
    Fiction                           3.769433    712.893617
    Travel                            3.760000   1002.000000
    Film                              3.750000   1513.000000
    Business                          3.730000    658.000000
    True Crime                        3.710000    739.500000
    Philosophy                        3.630000    422.000000
    Horror                            3.609091    765.954545
    Novella                           3.530000   1383.000000
    China                             2.880000    593.000000
    Top 3 Genres with Highest Ratings:
                 Average Rating  Average Rank
    Genre                                    
    Nature                 4.56        1338.0
    Time Travel            4.54         516.0
    Fairy Tales            4.50         924.0
    

### Goodreads Genres Analysis (2020)

According to this dataset of Goodreads in 2020, the genres with the highest average rating are **nature**, **time travel**, and **fairy tales**.

However, the average rank of **nature** is **1338**, suggesting that it is not widely read, but those who do read it seem to love it!  

The same can be said about **fairy tales** since its rank is 924.  

**Time travel** is both **well-read** (average rank of 516) and highly rated, making it popular and loved.


Genres like **Fiction** (3.77), **Young Adult** (3.88), and **Romance** (3.98) tend to have lower average ratings despite being widely read.




## Analyzing the Relationship Between Number of Ratings and Average Rating

### Objective:
- Create a **scatterplot** using **matplotlib** to examine the relationship between:
  - The **number of ratings** a book receives.
  - Its **average rating**.

### Purpose:
- Determine whether books with more ratings tend to have **higher** or **lower** average scores.

### Methodology:
1. Clean the data to ensure:
   - Valid numeric values for both **number of ratings** and **average rating**.
2. Use a **scatterplot** to visualize the relationship.
3. Analyze patterns to identify whether a trend exists.

### Expected Outcome:
- Insights into whether the popularity of a book (measured by the number of ratings) influences its perceived quality (measured by average rating).



```python
import pandas as pd
import matplotlib.pyplot as plt

# Reload the data
df = pd.read_csv('goodreads_books3_updated_2020.csv')

# Extract numeric values from 'Number of Ratings' and 'Average Rating'
df['Number of Ratings'] = df['Number of Ratings'].astype(str).str.extract(r'(\d[\d,]*)')[0]
df['Number of Ratings'] = pd.to_numeric(df['Number of Ratings'].str.replace(',', ''), errors='coerce')

df['Average Rating'] = df['Average Rating'].astype(str).str.extract(r'(\d+\.\d+)')[0]
df['Average Rating'] = pd.to_numeric(df['Average Rating'], errors='coerce')

# Drop rows with invalid or missing data
scatter_data = df.dropna(subset=['Number of Ratings', 'Average Rating'])

# Check the cleaned data
print(scatter_data[['Number of Ratings', 'Average Rating']].head())

# Plot the scatterplot
plt.figure(figsize=(10, 6))
plt.scatter(scatter_data['Number of Ratings'], scatter_data['Average Rating'],
            alpha=0.6, color='dodgerblue', edgecolors='black')

# Add titles and labels
plt.title('Relationship Between Number of Ratings and Average Rating', fontsize=16)
plt.xlabel('Number of Ratings', fontsize=12)
plt.ylabel('Average Rating', fontsize=12)

# Log scale for x-axis if values vary greatly
plt.xscale('log')

# Grid for better visualization
plt.grid(True, which="both", linestyle="--", linewidth=0.5)

# Show the plot
plt.tight_layout()
plt.show()

# Calculate the correlation coefficient
correlation = scatter_data['Number of Ratings'].corr(scatter_data['Average Rating'])
print(f"Correlation coefficient between Number of Ratings and Average Rating: {correlation:.2f}")

```

       Number of Ratings  Average Rating
    0             746915            4.39
    1             857133            4.47
    2            1226877            4.18
    3             616709            4.37
    4            2026238            3.99
    


    
![png](output_13_1.png)
    


    Correlation coefficient between Number of Ratings and Average Rating: 0.02
    

### Goodreads Books: Number of Ratings vs. Average Ratings Scatterplot

#### Key Findings:
1. **Weak Correlation**:
   - The relationship between the **number of ratings** and the **average rating** is very weak, as indicated by a correlation coefficient of **0.02**.
   - This suggests there is no significant linear relationship between the two variables.

2. **Spread of Average Ratings**:
   - Across all levels of "Number of Ratings" (from low to very high), the **Average Rating** remains spread across a wide range of values (approximately **3.0 to 4.5**).

3. **Implications**:
   - The number of ratings a book receives does not appear to directly influence its average rating.
   - Readers’ ratings seem to reflect the perceived quality of the book independently of its popularity (as measured by the number of ratings).

#### Conclusion:
The scatterplot demonstrates that while the number of ratings measures a book's popularity, it does not significantly affect how readers rate the book on average.




# Task 2 Author-Level Analysis of Neil Gaiman


```python
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd

# Initialize the WebDriver
driver = webdriver.Chrome()

# Set initial zoom to 40%
driver.get("about:blank")  # Open a blank page initially
driver.execute_script("document.body.style.zoom='40%'")
print("Initial zoom set to 40%.")

# Base URL for the author's book list
base_url = 'https://www.goodreads.com/author/list/1221698?page={}'

# List to store book details
books_data = []

# Function to scrape average rating and number of ratings
def scrape_ratings(page_number):
    try:
        # Navigate to the page
        driver.get(base_url.format(page_number))
        
        # Zoom out to 40% for the main page
        driver.execute_script("document.body.style.zoom='40%'")
        
        WebDriverWait(driver, 15).until(
            EC.presence_of_all_elements_located((By.XPATH, '//span[@class="minirating"]'))
        )
        
        # Find all books and their rating info
        book_titles = driver.find_elements(By.XPATH, '//a[@class="bookTitle"]')
        rating_elements = driver.find_elements(By.XPATH, '//span[@class="minirating"]')
        
        # Loop through the books and ratings
        for title, rating_info in zip(book_titles, rating_elements):
            book_title = title.text
            rating_text = rating_info.text

            # Extract average rating and number of ratings
            try:
                average_rating = rating_text.split(" avg rating")[0].strip()
                num_ratings = rating_text.split(" — ")[1].strip() if "—" in rating_text else "Not available"
            except:
                average_rating = "Not available"
                num_ratings = "Not available"

            books_data.append({
                "Title": book_title,
                "Average Rating": average_rating,
                "Number of Ratings": num_ratings,
            })
            print(f"Scraped: {book_title} | Avg Rating: {average_rating} | Num Ratings: {num_ratings}")
    except Exception as e:
        print(f"Error scraping page {page_number}: {e}")

# Main loop through all pages
for page_number in range(1, 71):
    print(f"Scraping page {page_number}...")
    scrape_ratings(page_number)

# Save results to CSV
df = pd.DataFrame(books_data)
df.to_csv('goodreads_ratings.csv', index=False)
print("Data saved to goodreads_ratings.csv")

# Close the WebDriver
driver.quit()

```

## I had issues processing the want to read, currently reading, and average ratings in this script above, so I created a seperate one that got the current reading, want to read values, and average ratings from Neil Gorman's books. 


```python
import pandas as pd

# Load the data from both CSV files
books_data = pd.read_csv("goodreads_author_booksBEST.csv")
ratings_data = pd.read_csv("goodreads_ratings.csv")

# Merge the datasets on the 'Title' column
merged_data = pd.merge(books_data, ratings_data, on="Title", how="left")

# Save the merged dataset to a new CSV file
merged_data.to_csv("merged_goodreads_books.csv", index=False)

print("Merged dataset saved to 'merged_goodreads_books.csv'")
```


```python
import pandas as pd

# Load the merged dataset and the currently reading/want-to-read data
merged_data = pd.read_csv("merged_goodreads_books.csv")
reading_data = pd.read_csv("goodreads_author_currently_reading.csv")

# Merge the datasets on the 'Title' column
final_merged_data = pd.merge(merged_data, reading_data[['Title', 'Currently Reading', 'Want to Read']], on="Title", how="left")

# Save the final dataset to a new CSV file
final_merged_data.to_csv("final_goodreads_books.csv", index=False)

print("Final dataset saved to 'final_goodreads_books.csv'")
```

## Cleaning the data below to remove duplicates


```python
import pandas as pd

# Load the CSV file
file_path = 'final_goodreads_author_books.csv'  
df = pd.read_csv(file_path)

# Remove duplicates based on 'Title' and 'Publication Date'
df_cleaned = df.drop_duplicates(subset=['Title', 'Publication Date'])

# Save the cleaned DataFrame to a new CSV file
cleaned_file_path = 'cleaned_goodreads_author_books.csv' 
df_cleaned.to_csv(cleaned_file_path, index=False)

print(f"Cleaned file saved to: {cleaned_file_path}")
```

## Cleaning the data below to get to accurately describe Average Rating and get rid of Average Rating duplicate column



```python
import pandas as pd

# Load your file
file_path = 'cleaned_goodreads_author_books.csv'  # Replace with the path to your file
df = pd.read_csv(file_path)

# Drop the redundant column 'Average Rating_x'
if 'Average Rating_x' in df.columns:
    df = df.drop(columns=['Average Rating_x'])

# Rename the column 'Average Rating_y' to 'Average Rating'
if 'Average Rating_y' in df.columns:
    df = df.rename(columns={'Average Rating_y': 'Average Rating'})

# Save the updated file
updated_file_path = 'cleaned_goodreads_author_books_updated.csv'  # Replace with the desired file name
df.to_csv(updated_file_path, index=False)

print(f"Updated file saved as: {updated_file_path}")
```

## Grouping Books by Language

### Objective:
- Determine how many books Neil Gaiman has published in **English** and in **other languages**.

### Methodology:
1. Group the dataset by the **Language** column.
2. Count the number of books for each language.

### Purpose:
- Gain insight into the distribution of Neil Gaiman's books across different languages.
- Identify whether the majority of his work is published in English or translated into other languages.
 


```python
# Group by 'Language' and count the number of books for each language
import pandas as pd
df = pd.read_csv('cleaned_goodreads_author_books_updated.csv')
language_distribution = df['Language'].value_counts().reset_index()
language_distribution.columns = ['Language', 'Book Count']

# Display the result
print(language_distribution)
```

                     Language  Book Count
    0                 English        1237
    1           Not available         122
    2      Spanish; Castilian         107
    3                 Italian          77
    4                  French          44
    5              Portuguese          40
    6                  German          25
    7                  Polish          21
    8                 Russian          19
    9                  Arabic           5
    10  Greek, Modern (1453-)           5
    11                Chinese           4
    12                  Czech           3
    13               Croatian           3
    14                Finnish           3
    15              Hungarian           2
    16                Serbian           2
    17                 Korean           1
    18         Dutch; Flemish           1
    19             Vietnamese           1
    20                 Hebrew           1
    21                Turkish           1
    22             Indonesian           1
    23              Bulgarian           1
    24              Mongolian           1
    25               Romanian           1
    26              Norwegian           1
    

### Goodreads Books: Language Distribution Analysis

#### Key Observations:
1. **Predominance of English**:
   - The majority of Neil Gaiman's books are in **English**, indicating that he primarily writes in this language.

2. **Global Reach**:
   - The presence of many other languages shows that Neil Gaiman's books are enjoyed by readers worldwide and have been translated into multiple languages.

3. **Popular Non-English Languages**:
   - While no language is as predominant as English, notable languages with higher counts include **Spanish**, **Italian**, **French**, and **Portuguese**. These may represent popular publishing or translation languages.

4. **Language Diversity**:
   - Neil Gaiman's books are available in **26 different languages**, demonstrating a wide diversity in language distribution.

#### Conclusion:
Neil Gaiman's books have a strong global presence, with translations into many languages, reflecting their universal appeal and popularity beyond English-speaking audiences.


## Plotting the Relationship Between Neil Gaiman's Age and Page Count
We want to figure out if there is a relationship between the number of pages and a book's average rating.
To visualize the relationship between Neil Gaiman's age and the page count of his books, I use **matplotlib** for plotting. 

The publishing date is used to calculate his age at the time of publication by subtracting his birthday using a **lambda expression** with the `datetime` module.

Assumptions:
- All valid ages are between **0 and 120 years**.



```python
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime

# Step 1: Load the data
df = pd.read_csv('cleaned_goodreads_author_books_updated.csv')


# Extract the year from 'Publication Date'
df['Publication Year'] = df['Publication Date'].str.extract(r'(\d{4})').astype(float)

# Drop rows where 'Publication Year' or 'Number of Pages' is missing
df = df.dropna(subset=['Publication Year', 'Number of Pages'])

# Convert 'Number of Pages' to numeric
df['Number of Pages'] = pd.to_numeric(df['Number of Pages'], errors='coerce')

# Step 2: Calculate author's age at publication
author_birthdate = datetime(1960, 11, 10)  # Neil Gaiman's birthdate
df['Author Age'] = df['Publication Year'].apply(lambda x: int(x) - author_birthdate.year)

# Remove invalid ages
df = df[(df['Author Age'] >= 0) & (df['Author Age'] < 120)]  # Assuming valid ages are between 0 and 120

# Step 3: Plot the relationship (Author Age vs. Number of Pages)
plt.figure(figsize=(10, 6))
plt.plot(df['Author Age'], df['Number of Pages'], marker='o', linestyle='-', color='b')
plt.title("Relationship Between Author's Age and Page Count")
plt.xlabel("Author's Age")
plt.ylabel("Number of Pages")
plt.grid(True)

# Display the plot
plt.show()

```


    
![png](output_28_0.png)
    


# Analysis of Neil Gaiman's Age and Page Count

- The books do not show an increase in page count as Neil Gaiman gets older. 
  - Most books are under **500 pages**, with some notable outliers.
  - These outliers are more likely to occur as he gets older, but there is no clear upward trend indicating that he is creating longer books overall.

- Books listed around the ages of **0–18** may exist due to:
  - Errors in the data or contributions to books in the future that Neil Gaiman did not author directly.
  - These entries may have been incorrectly categorized on the website.

- **Clustering**:
  - Most of Neil Gaiman's books are clustered between the ages of **30 and 60**, indicating that this has been the prime of his career so far.


# Analyzing the Relationship Between Currently Reading and Ratings

I aim to determine if there is a relationship between the number of people currently reading a book and the number of ratings it has received.

## Methodology:
1. **Data Cleaning**:
   - Extracted numerical values for:
     - The number of people currently reading.
     - The total number of ratings.
     - The average rating.
   - Ensured only valid numeric data was used.

2. **Visualization**:
   - Created two scatterplots using **matplotlib**:
     - **Plot 1**: Currently Reading vs. Number of Ratings.
     - **Plot 2**: Currently Reading vs. Average Rating.
   - Applied a log scale to the x-axis to handle the wide range of values due to high counts for some books.

## Objective:
- To explore whether there is a correlation between:
  - The number of people currently reading a book and the total ratings it has received.
  - The number of people currently reading a book and its average rating.



```python
import pandas as pd
import matplotlib.pyplot as plt

# Reload the data
df = pd.read_csv('cleaned_goodreads_author_books_updated.csv')

# Extract numeric values from 'Currently Reading', 'Number of Ratings', and 'Average Rating'
df['Currently Reading'] = df['Currently Reading'].astype(str).str.extract(r'(\d[\d,]*)')[0]
df['Currently Reading'] = pd.to_numeric(df['Currently Reading'].str.replace(',', ''), errors='coerce')

df['Number of Ratings'] = df['Number of Ratings'].astype(str).str.extract(r'(\d[\d,]*)')[0]
df['Number of Ratings'] = pd.to_numeric(df['Number of Ratings'].str.replace(',', ''), errors='coerce')

df['Average Rating'] = df['Average Rating'].astype(str).str.extract(r'(\d+\.\d+)')[0]
df['Average Rating'] = pd.to_numeric(df['Average Rating'], errors='coerce')

# Drop rows with invalid or missing data for both plots
scatter_data_ratings = df.dropna(subset=['Currently Reading', 'Number of Ratings'])
scatter_data_avg = df.dropna(subset=['Currently Reading', 'Average Rating'])

# Ensure all values are positive
scatter_data_ratings = scatter_data_ratings[(scatter_data_ratings['Currently Reading'] > 0) & 
                                            (scatter_data_ratings['Number of Ratings'] > 0)]
scatter_data_avg = scatter_data_avg[(scatter_data_avg['Currently Reading'] > 0) & 
                                    (scatter_data_avg['Average Rating'] > 0)]

# Plot 1: Currently Reading vs. Number of Ratings
plt.figure(figsize=(10, 6))
plt.scatter(scatter_data_ratings['Currently Reading'], scatter_data_ratings['Number of Ratings'],
            alpha=0.6, color='dodgerblue', edgecolors='black')

# Titles and labels
plt.title('Currently Reading vs. Number of Ratings', fontsize=16)
plt.xlabel('Number of People Currently Reading', fontsize=12)
plt.ylabel('Number of Ratings', fontsize=12)

# Log scale for x-axis and y-axis
plt.xscale('log')
plt.yscale('log')

# Grid for better visualization
plt.grid(True, which="both", linestyle="--", linewidth=0.5)

# Show the plot
plt.tight_layout()
plt.show()

# Plot 2: Currently Reading vs. Average Rating
plt.figure(figsize=(10, 6))
plt.scatter(scatter_data_avg['Currently Reading'], scatter_data_avg['Average Rating'],
            alpha=0.6, color='orange', edgecolors='black')

# Titles and labels
plt.title('Currently Reading vs. Average Rating', fontsize=16)
plt.xlabel('Number of People Currently Reading', fontsize=12)
plt.ylabel('Average Rating', fontsize=12)

# Log scale for x-axis
plt.xscale('log')

# Grid for better visualization
plt.grid(True, which="both", linestyle="--", linewidth=0.5)

# Show the plot
plt.tight_layout()
plt.show()

# Calculate and display correlations
correlation_ratings = scatter_data_ratings['Currently Reading'].corr(scatter_data_ratings['Number of Ratings'])
correlation_avg = scatter_data_avg['Currently Reading'].corr(scatter_data_avg['Average Rating'])

print(f"Correlation between Currently Reading and Number of Ratings: {correlation_ratings:.2f}")
print(f"Correlation between Currently Reading and Average Rating: {correlation_avg:.2f}")

```


    
![png](output_31_0.png)
    



    
![png](output_31_1.png)
    


    Correlation between Currently Reading and Number of Ratings: 0.16
    Correlation between Currently Reading and Average Rating: -0.01
    

# Analysis of Scatterplots: Currently Reading vs. Ratings

## Plot 1: Currently Reading vs. Number of Ratings
- **Observation**:
  - There is a **positive correlation** between the number of people currently reading a book and the number of ratings it has received.
  - As the number of current readers increases, the number of ratings tends to grow as well.
  - The data shows wider variability in the number of ratings for books with a high number of current readers.
  
- **Insight**:
  - Popular books (those with more current readers) are more likely to have accumulated a large number of ratings over time.
  - However, the correlation coefficient of **0.15** suggests that this relationship is weak, indicating other factors also influence the total number of ratings.

---

## Plot 2: Currently Reading vs. Average Rating
- **Observation**:
  - There is no clear pattern between the number of people currently reading a book and its average rating.
  - The average rating remains relatively stable, mostly falling between **3.5 and 4.5**, regardless of the number of current readers.
  - The correlation coefficient of **-0.01** confirms the absence of a significant relationship.

- **Insight**:
  - The number of people currently reading a book does not influence its average rating.
  - This suggests that average ratings are more likely determined by the perceived quality of the book rather than its current popularity.

---


These findings suggest that while the number of current readers can indicate overall popularity (via total ratings), it has no meaningful impact on a book's quality as reflected in its average rating at least for Neil Gaiman.



```python

```
